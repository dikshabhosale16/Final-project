package com.laptoppak.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.laptoppak.model.Payment;



public interface PaymentRepository extends JpaRepository<Payment,Integer>{

}
