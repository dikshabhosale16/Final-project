package com.laptoppak.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.laptoppak.model.User;


public interface UserRepository extends JpaRepository<User,Long> {

	 @Query(value ="select * from user a where (a.Email_Id= ?1 or a.mobile_no= ?1) && a.password = ?2",nativeQuery = true)
	 public  User findbyusername(String emailId, String password);
	


}
