package com.laptoppak.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;

@Entity
@Table
public class Product {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@GeneratedValue(strategy=GenerationType.AUTO, generator="productGenerator")
	@SequenceGenerator(name="productGenerator", sequenceName="productGenerator", allocationSize=1)
	@Column(name="Product_id")
	private int productId;
	
	@Column(name="Product_Name")
	//@NotEmpty
	private String productName;
	
	@Column(name="Product_Brand")
	//@NotEmpty
	private String productBrand;
	
	@Column(name="Product_Price")
	//@NotEmpty
	private long productPrice;
	
	@Column(name="Product_Colour")
	//@NotEmpty
	private String productColour;
	
	@Column(name="Product_Quality")//For Rating Purpose 
	//@NotEmpty
	private String productQuality;
	
	@Column(name="Product_Quantity")
	//@NotEmpty
	private int productQuantity;
	
	@Column(name="Product_Processor")
	//@NotEmpty
	private String productProcessor;
	
	@Column(name="Product_RAM")
	//@NotEmpty
	private String productRAM;
	
	@Column(name="Product_SSD")
	//@NotEmpty
	private String productSSD;
	
	@Column(name="Product_Keyboard")
	//@NotEmpty
	private String productKeyboard;
	
	@Column(name="Product_Mouse")
	//@NotEmpty
	private String productMouse;
		
	@Column(name="Product_Ports")
	//@NotEmpty
	private String productPorts;
	
	@Column(name="Product_Hard_Drive")
	//@NotEmpty
	private String productHardDrive;
	
	private String productAbout;
	
	private String Link;
	
	private String Link1;
	
	private String Link2;
	
	private String Link3;
	
	
//	@OneToMany(cascade = CascadeType.ALL)
//    private List<Cart> carts;
	

	
	@ManyToOne
    @JoinColumn(name = "user_Id")
    private User user;
	
	public Product()
	{
		
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public long getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductColour() {
		return productColour;
	}

	public void setProductColour(String productColour) {
		this.productColour = productColour;
	}

	public String getProductQuality() {
		return productQuality;
	}

	public void setProductQuality(String productQuality) {
		this.productQuality = productQuality;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductProcessor() {
		return productProcessor;
	}

	public void setProductProcessor(String productProcessor) {
		this.productProcessor = productProcessor;
	}

	public String getProductRAM() {
		return productRAM;
	}

	public void setProductRAM(String productRAM) {
		this.productRAM = productRAM;
	}

	public String getProductSSD() {
		return productSSD;
	}

	public void setProductSSD(String productSSD) {
		this.productSSD = productSSD;
	}

	public String getProductKeyboard() {
		return productKeyboard;
	}

	public void setProductKeyboard(String productKeyboard) {
		this.productKeyboard = productKeyboard;
	}

	public String getProductMouse() {
		return productMouse;
	}

	public void setProductMouse(String productMouse) {
		this.productMouse = productMouse;
	}

	public String getProductPorts() {
		return productPorts;
	}

	public void setProductPorts(String productPorts) {
		this.productPorts = productPorts;
	}

	public String getProductHardDrive() {
		return productHardDrive;
	}

	public void setProductHardDrive(String productHardDrive) {
		this.productHardDrive = productHardDrive;
	}

	public String getProductAbout() {
		return productAbout;
	}

	public void setProductAbout(String productAbout) {
		this.productAbout = productAbout;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String link) {
		Link = link;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	public String getLink1() {
		return Link1;
	}

	public void setLink1(String link1) {
		Link1 = link1;
	}

	public String getLink2() {
		return Link2;
	}

	public void setLink2(String link2) {
		Link2 = link2;
	}

	public String getLink3() {
		return Link3;
	}

	public void setLink3(String link3) {
		Link3 = link3;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productBrand=" + productBrand
				+ ", productPrice=" + productPrice + ", productColour=" + productColour + ", productQuality="
				+ productQuality + ", productQuantity=" + productQuantity + ", productProcessor=" + productProcessor
				+ ", productRAM=" + productRAM + ", productSSD=" + productSSD + ", productKeyboard=" + productKeyboard
				+ ", productMouse=" + productMouse + ", productPorts=" + productPorts + ", productHardDrive="
				+ productHardDrive + ", productAbout=" + productAbout + ", Link=" + Link + ", Link1=" + Link1
				+ ", Link2=" + Link2 + ", Link3=" + Link3 + ", user=" + user + "]";
	}

	

	
	
	

	

	
	
	}

