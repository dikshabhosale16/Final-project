package com.laptoppak.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="OrderTable")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="orderGenerator")
	@SequenceGenerator(name="orderGenerator", sequenceName="orderGenerator", allocationSize=1)
	@Column(name="Order_Id")
	private int orderId;
	
	@Column(name="User_Id")
	private long userId;
	
	@Column(name="Order_Status")
	private String orderStatus;
	
	@Column(name="Product_Id")
	private int productId;
	
	@Column(name="User_Address")
	private String userAddress;
	
	@Column(name="Order_Quantity")
	private int orderQuantity;
	
	
//	@ManyToMany
//	@JoinColumn(name = "user_Id")
//	private User user;

//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "orderId")
//	private List<Cart> cart;
//	
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "orderId")
//    private List<User> user;
	
//	@ManyToOne
//    @JoinColumn(name = "user_Id")
//    private User user;
//	

	public Order()
	{

	}

	

	


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public long getUserId() {
		return userId;
	}


	public void setUserId(long userId) {
		this.userId = userId;
	}


	public String getOrderStatus() {
		return orderStatus;
	}


	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getUserAddress() {
		return userAddress;
	}


	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}


	public int getOrderQuantity() {
		return orderQuantity;
	}


	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}






	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", userId=" + userId + ", orderStatus=" + orderStatus + ", productId="
				+ productId + ", userAddress=" + userAddress + ", orderQuantity=" + orderQuantity + "]";
	}



	

	


	


	


}
