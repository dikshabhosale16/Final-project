package com.laptoppak.service;

import java.util.List;


import com.laptoppak.model.User;


public interface UserService {

	public User saveUser(User user);
	public List<User> getAllUsers();
	public User getUserById(long userId);
	public void removeUser(long userId);
	public User updateUser(User user, long userId);
	
	//getting user by name
	public User findbyusername(String emailId, String password);
	
}
