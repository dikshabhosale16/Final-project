package com.laptoppak.service;

import java.util.List;
import com.laptoppak.model.Product;


public interface ProductService {
	
	public Product saveProduct(Product product);
	public List<Product> getAllProducts();
	public Product getProductById(int productId);
	public void removeProduct(int productId);
	public Product updateProduct(Product product, int productId);

}
