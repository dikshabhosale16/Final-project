package com.laptoppak.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptoppak.exceptionhandling.ResourceNotFoundException;
import com.laptoppak.model.User;
import com.laptoppak.repository.UserRepository;
import com.laptoppak.service.UserService;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository ;
	
	//addUser
	@Override
	public User saveUser(User user) {
		
		return userRepository.save(user);
	}

	//GetAllUser
	@Override
	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}

	//GetUserById
	@Override
	public User getUserById(long userId) {
		 Optional<User> user=userRepository.findById((long) userId);
		  if(user.isPresent()) { return user.get(); }else throw new
		  ResourceNotFoundException("User","userId",userId);
	}

	//DeleteUser
	@Override
	public void removeUser(long userId) {
		userRepository.findById((long) userId).orElseThrow(()->new ResourceNotFoundException("User","userId",userId));
		userRepository.deleteById((long) userId);

		
	}

	//Update User
	@Override
	public User updateUser(User user, long userId) {
		User existingUser=userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User","userId",userId));
		
		existingUser.setAddress(user.getAddress());
		existingUser.setDistrict(user.getDistrict());
		existingUser.setEmailId(user.getEmailId());
		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.setMobileNo(user.getMobileNo());
		existingUser.setPassword(user.getPassword());
		existingUser.setPincode(user.getPincode());
		existingUser.setState(user.getState());
		
		
		userRepository.save(existingUser);
		return existingUser;
	}

	//find user by name
	@Override
	public User findbyusername(String emailId, String password) {
		
		return userRepository.findbyusername(emailId,password);
	}

	
	
}
