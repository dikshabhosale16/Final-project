package com.laptoppak.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptoppak.exceptionhandling.ResourceNotFoundException;
import com.laptoppak.model.Product;
import com.laptoppak.repository.ProductRepository;
import com.laptoppak.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {

		return productRepository.findAll();
	}

	@Override
	public Product getProductById(int productId) {

		Optional<Product> product=productRepository.findById(productId);
		if(product.isPresent()) 
		{
			return product.get(); 
		}else throw new ResourceNotFoundException("Product","productId",productId);
	}

	@Override
	public void removeProduct(int productId) {
		productRepository.findById(productId).orElseThrow(()->new ResourceNotFoundException("Product","productId",productId));
		productRepository.deleteById(productId);

	}

	@Override
	public Product updateProduct(Product product, int productId) {
		Product existingProduct=productRepository.findById(productId).orElseThrow(()->new ResourceNotFoundException("Product","productId",productId));
		existingProduct.setProductName(product.getProductName());
		existingProduct.setProductBrand(product.getProductBrand());
		existingProduct.setProductColour(product.getProductColour());
		existingProduct.setProductHardDrive(product.getProductHardDrive());
		existingProduct.setProductKeyboard(product.getProductKeyboard());
		existingProduct.setProductMouse(product.getProductMouse());
		existingProduct.setProductPrice(product.getProductPrice());
		existingProduct.setProductProcessor(product.getProductProcessor());
		existingProduct.setProductQuality(product.getProductQuality());
		existingProduct.setProductQuantity(product.getProductQuantity());
		existingProduct.setProductRAM(product.getProductRAM());
		existingProduct.setProductSSD(product.getProductSSD());
		existingProduct.setProductAbout(product.getProductAbout());
		existingProduct.setLink(product.getLink());
		existingProduct.setLink1(product.getLink1());
		existingProduct.setLink2(product.getLink2());
		existingProduct.setLink3(product.getLink3());

		productRepository.save(existingProduct);
		return existingProduct;
	}


}
